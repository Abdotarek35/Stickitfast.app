package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Stick It Fast", appName)
  }

  @Test
  fun `save and load notes`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val note = NoteData(id = "test-1", text = "Hello Sticky Note", color = "#FFE066")
    NoteStore.saveNotes(context, listOf(note))
    val loaded = NoteStore.loadNotes(context)
    assertEquals(1, loaded.size)
    assertEquals("Hello Sticky Note", loaded[0].text)
  }

  @Test
  fun `save and get default note color`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    NoteStore.setDefaultColor(context, "#A8D8B9")
    val defaultColor = NoteStore.getDefaultColor(context)
    assertEquals("#A8D8B9", defaultColor)
  }

  @Test
  fun `save and load note with size preset and ruled lines`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val note = NoteData(
      id = "test-custom",
      text = "Note with custom preset",
      sizePreset = 0,
      ruledLines = false
    )
    NoteStore.saveNotes(context, listOf(note))
    val loaded = NoteStore.loadNotes(context)
    val found = loaded.first { it.id == "test-custom" }
    assertEquals(0, found.sizePreset)
    assertEquals(false, found.ruledLines)
  }
}

package com.example

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.UUID

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val activeNotes = mutableListOf<NoteWindow>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var undoBar: UndoBar? = null
    private var pendingRemovalData: NoteData? = null
    private var pendingRemovalRunnable: Runnable? = null
    private var addFab: AddFab? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundWithNotification()

        if (!Settings.canDrawOverlays(this)) {
            // الإذن اتشال فجأة (أو الخدمة اتنادت من الـ widget قبل ما الإذن يتاخد) - افتح الشاشة الرئيسية بدل ما نكراش
            val openApp = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                startActivity(openApp)
            } catch (e: Exception) {
                // تجاهل بهدوء
            }
            stopSelf()
            return
        }

        val savedNotes = NoteStore.loadNotes(this)
        val defaultColor = NoteStore.getDefaultColor(this)
        val toShow = if (savedNotes.isEmpty()) {
            listOf(NoteData(id = UUID.randomUUID().toString(), color = defaultColor))
        } else {
            savedNotes
        }
        toShow.forEach {
            try {
                addNoteWindow(it)
            } catch (e: Exception) {
                // لو نوتة واحدة فيها مشكلة، منسيبهاش توقف باقي النوتات
            }
        }
        updateNotification()

        addFab = AddFab(this, windowManager) { addNoteQuick() }
        addFab?.show()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_GATHER -> gatherNotes()
            ACTION_ADD_NOTE -> {
                if (Settings.canDrawOverlays(this)) {
                    addNoteQuick()
                }
            }
        }
        return START_STICKY
    }

    private fun addNoteWindow(data: NoteData) {
        val note = NoteWindow(
            context = this,
            windowManager = windowManager,
            data = data,
            onRemove = { removeNoteWindow(it) },
            onChanged = { persistAll() }
        )
        activeNotes.add(note)
    }

    // بيتنادى من زرار الـ FAB الثابت أسفل يمين الشاشة
    private fun addNoteQuick() {
        val defaultColor = NoteStore.getDefaultColor(this)
        addNoteWindow(NoteData(id = UUID.randomUUID().toString(), color = defaultColor))
        persistAll()
        updateNotification()
    }

    private fun removeNoteWindow(note: NoteWindow) {
        note.detach()
        activeNotes.remove(note)
        updateNotification()
        scheduleUndoableRemoval(note.data)
    }

    // بدل الحذف الفوري: بنستنى ٤ ثواني وبنوري شريط "تراجع" قبل ما نمسح النوتة نهائيًا
    private fun scheduleUndoableRemoval(data: NoteData) {
        pendingRemovalRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingRemovalData = null
        undoBar?.dismiss()

        pendingRemovalData = data
        persistAll()

        val bar = UndoBar(this, windowManager)
        undoBar = bar
        bar.show(
            message = "اتقفلت النوتة",
            actionLabel = "تراجع",
            onAction = { undoRemoval() }
        )

        val runnable = Runnable {
            pendingRemovalData = null
            undoBar?.dismiss()
            undoBar = null
            if (activeNotes.isEmpty()) {
                stopSelf()
            }
        }
        pendingRemovalRunnable = runnable
        mainHandler.postDelayed(runnable, UNDO_DELAY_MS)
    }

    private fun undoRemoval() {
        pendingRemovalRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingRemovalRunnable = null
        val data = pendingRemovalData ?: return
        pendingRemovalData = null
        undoBar?.dismiss()
        undoBar = null
        try {
            addNoteWindow(data)
            persistAll()
            updateNotification()
        } catch (e: Exception) {
            // تجاهل بهدوء
        }
    }

    // بيرجّع كل النوتات المتناثرة (خصوصًا اللي راحت برا حدود الشاشة) لمكان واحد مرتب
    private fun gatherNotes() {
        if (activeNotes.isEmpty()) return
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val baseX = (screenWidth * 0.08f).toInt()
        val baseY = (screenHeight * 0.18f).toInt()
        val step = (28 * resources.displayMetrics.density).toInt()

        activeNotes.forEachIndexed { index, note ->
            val targetX = (baseX + index * step).coerceAtMost((screenWidth - step).coerceAtLeast(0))
            val targetY = (baseY + index * step).coerceAtMost((screenHeight - step).coerceAtLeast(0))
            note.gatherTo(targetX, targetY, staggerMs = index * 60L)
        }
        mainHandler.postDelayed({ persistAll() }, 300L + activeNotes.size * 60L)
    }

    private fun persistAll() {
        NoteStore.saveNotes(this, activeNotes.map { it.data })
    }

    private fun startForegroundWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "stick_it_fast_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Stick It Fast", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        val count = activeNotes.size
        val countText = when (count) {
            0 -> "مفيش نوتات شغالة دلوقتي"
            1 -> "عندك نوتة واحدة شغالة"
            2 -> "عندك ٢ نوتة شغالة"
            else -> "عندك $count نوتات شغالة"
        }

        val gatherIntent = Intent(this, OverlayService::class.java).apply { action = ACTION_GATHER }
        val gatherPendingIntent = PendingIntent.getService(
            this, 2, gatherIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Stick It Fast شغالة")
            .setContentText(countText)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentIntent(pendingIntent)
            .addAction(0, "تجميع النوتات", gatherPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val restartIntent = Intent(applicationContext, OverlayService::class.java)
        restartIntent.setPackage(packageName)
        val restartPendingIntent = PendingIntent.getService(
            this, 1, restartIntent, PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmService = getSystemService(ALARM_SERVICE) as AlarmManager
        alarmService.set(
            AlarmManager.ELAPSED_REALTIME,
            SystemClock.elapsedRealtime() + 1000,
            restartPendingIntent
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        pendingRemovalRunnable?.let { mainHandler.removeCallbacks(it) }
        undoBar?.dismiss()
        addFab?.hide()
        activeNotes.forEach { it.detach() }
    }

    companion object {
        const val ACTION_GATHER = "com.example.ACTION_GATHER"
        const val ACTION_ADD_NOTE = "com.example.ACTION_ADD_NOTE"
        private const val NOTIFICATION_ID = 1
        private const val UNDO_DELAY_MS = 4000L
    }
}

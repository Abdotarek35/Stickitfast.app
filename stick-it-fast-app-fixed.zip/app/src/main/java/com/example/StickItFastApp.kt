package com.example

import android.app.Application
import android.content.Context
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

// بيسجّل تفاصيل أي كراش يحصل في أي حتة في التطبيق (تلقائيًا، من غير ما نعرف مقدمًا فين
// المشكلة) عشان نقدر نشوف النص الحقيقي للخطأ بدل ما نخمّن. النص بيتحفظ محليًا بس على
// جهازك، ومبيتبعتش لحتة تانية خالص - إنت اللي بتنسخه وتبعتهولي يدويًا لو حبيت.
class StickItFastApp : Application() {

    companion object {
        private const val PREFS = "stick_it_fast_prefs"
        private const val KEY_CRASH_LOG = "last_crash_log"

        fun getSavedCrashLog(context: Context): String? {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return prefs.getString(KEY_CRASH_LOG, null)
        }

        fun clearSavedCrashLog(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_CRASH_LOG)
                .apply()
        }

        // بتُستخدم لما جزء من الكود (زي OverlayService) يمسك مشكلة بنفسه بدل ما
        // يسيبها توصل لحد الكراش الكامل - بنسجّلها هنا بنفس الطريقة عشان تظهر
        // في نفس نافذة التشخيص
        fun logCaughtError(context: Context, source: String, throwable: Throwable) {
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val log = "الوقت: ${Date()}\nالمصدر: $source (اتمسكت قبل ما تكرش التطبيق)\n\n$sw"
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_CRASH_LOG, log)
                    .apply()
            } catch (e: Exception) {
                // تجاهل بهدوء
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                val log = "الوقت: ${Date()}\nالخيط: ${thread.name}\n\n$sw"
                getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_CRASH_LOG, log)
                    .commit() // commit مش apply - لازم يتسجّل فورًا قبل ما التطبيق يقفل
            } catch (e: Exception) {
                // تجاهل بهدوء - أهم حاجة إننا منمنعش التصرف الافتراضي للنظام يكمل تحت
            }
            // نسيب النظام يكمل تصرفه الطبيعي بعد ما سجّلنا التفاصيل
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}

package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/**
 * منظر ورقة الزاوية المنطوية ثلاثية الأبعاد (Paper Corner Curl)
 * يرسم مثلث الزاوية المطوية مع ظلال وتدرجات ورقية واقعية
 */
class PaperCurlView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var paperColor: Int = Color.parseColor("#FFE066")

    private val foldPath = Path()
    private val shadowPath = Path()

    private val foldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val foldShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#40000000")
    }

    private val creasePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.parseColor("#30000000")
    }

    fun setPaperColor(color: Int) {
        paperColor = color
        // اللون الداخلي للورقة المطوية أفتح قليلاً مع إحساس بياض الظهر
        val r = (Color.red(color) * 0.7f + 255 * 0.3f).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * 0.7f + 255 * 0.3f).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * 0.7f + 255 * 0.3f).toInt().coerceIn(0, 255)
        foldPaint.color = Color.rgb(r, g, b)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // رسم ظل الانطواء أسفل الزاوية
        shadowPath.reset()
        shadowPath.moveTo(0f, h)
        shadowPath.lineTo(w, 0f)
        shadowPath.lineTo(w * 0.85f, h * 0.85f)
        shadowPath.close()
        canvas.drawPath(shadowPath, foldShadowPaint)

        // رسم مثلث الورقة المطوية
        foldPath.reset()
        foldPath.moveTo(0f, h)
        foldPath.lineTo(w, 0f)
        foldPath.lineTo(w, h)
        foldPath.close()
        canvas.drawPath(foldPath, foldPaint)

        // رسم خط الثني التجسيمي
        canvas.drawLine(0f, h, w, 0f, creasePaint)
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}

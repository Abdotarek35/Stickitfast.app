package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AddNoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.widget_add_note)

            // استقلالية كاملة: دوسة الودجت بتطلق نوتة عايمة فورًا مباشرة من الخدمة،
            // من غير ما تفتح التطبيق خالص. الكتابة نفسها بتتم على النوتة العايمة
            // بعد ما تظهر - مش جوه الودجت (أندرويد مش بيسمح بكتابة نص حقيقية جوه
            // أي ودجت على الإطلاق، ده قيد من النظام نفسه مش قصور فينا).
            val intent = Intent(context, OverlayService::class.java).apply {
                action = OverlayService.ACTION_ADD_NOTE
            }
            val pendingIntent = PendingIntent.getService(
                context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)

            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}

package com.example

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    // عناصر الشريط العلوي والحالة
    private lateinit var statusBadge: TextView
    private lateinit var actionButton: Button
    private lateinit var updateBanner: TextView

    // أزرار لوحة التحكم السريعة (Power Action Bar)
    private lateinit var btnPowerLaunch: View
    private lateinit var btnPowerAdd: View
    private lateinit var btnPowerGather: View
    private lateinit var btnPowerHide: View

    // محاكي الشاشة الحية (Live Interactive Phone Simulator)
    private lateinit var simPhoneScreen: FrameLayout
    private lateinit var simNoteDraggable: View
    private lateinit var simNoteText: EditText
    private lateinit var simSizeBadge: TextView
    private lateinit var simMinBtn: View
    private lateinit var simResetSimBtn: View

    // استوديو النوتة الفورية (Quick Note Studio)
    private lateinit var studioNoteInput: EditText
    private lateinit var studioSizeSmallBtn: TextView
    private lateinit var studioSizeMediumBtn: TextView
    private lateinit var studioLaunchFloatingBtn: Button
    private lateinit var studioSaveGalleryBtn: Button
    private lateinit var paletteSwatchesContainer: LinearLayout
    private lateinit var settingsHueBar: View
    private lateinit var selectedColorIndicator: View
    private lateinit var selectedColorText: TextView

    // معرض النوتات المحفوظة (Notes Gallery)
    private lateinit var gallerySearchInput: EditText
    private lateinit var galleryNotesContainer: LinearLayout
    private lateinit var galleryEmptyState: View
    private lateinit var galleryCountBadge: TextView

    // حالة التطبيق
    private var currentColor: String = NoteStore.DEFAULT_COLOR_VALUE
    private var studioSelectedSize: Int = 0 // 0 = صغير (الافتراضي), 1 = متوسط
    private var studioRuledLines: Boolean = true
    private val swatchViews = mutableListOf<Pair<String, View>>()
    private var allSavedNotes = mutableListOf<NoteData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        loadInitialData()

        setupPowerActionBar()
        setupPaletteSelector()
        setupHueBar()
        setupQuickStudio()
        setupLivePhoneSimulator()
        setupNotesGallery()

        checkForUpdate()
    }

    private fun bindViews() {
        statusBadge = findViewById(R.id.statusBadge)
        actionButton = findViewById(R.id.actionButton)
        updateBanner = findViewById(R.id.updateBanner)

        btnPowerLaunch = findViewById(R.id.btnPowerLaunch)
        btnPowerAdd = findViewById(R.id.btnPowerAdd)
        btnPowerGather = findViewById(R.id.btnPowerGather)
        btnPowerHide = findViewById(R.id.btnPowerHide)

        simPhoneScreen = findViewById(R.id.simPhoneScreen)
        simNoteDraggable = findViewById(R.id.simNoteDraggable)
        simNoteDraggable.clipToOutline = true
        simNoteText = findViewById(R.id.simNoteText)
        simSizeBadge = findViewById(R.id.simSizeBadge)
        simMinBtn = findViewById(R.id.simMinBtn)
        simResetSimBtn = findViewById(R.id.simResetSimBtn)

        studioNoteInput = findViewById(R.id.studioNoteInput)
        studioSizeSmallBtn = findViewById(R.id.studioSizeSmallBtn)
        studioSizeMediumBtn = findViewById(R.id.studioSizeMediumBtn)
        studioLaunchFloatingBtn = findViewById(R.id.studioLaunchFloatingBtn)
        studioSaveGalleryBtn = findViewById(R.id.studioSaveGalleryBtn)
        paletteSwatchesContainer = findViewById(R.id.paletteSwatchesContainer)
        settingsHueBar = findViewById(R.id.settingsHueBar)
        selectedColorIndicator = findViewById(R.id.selectedColorIndicator)
        selectedColorText = findViewById(R.id.selectedColorText)

        gallerySearchInput = findViewById(R.id.gallerySearchInput)
        galleryNotesContainer = findViewById(R.id.galleryNotesContainer)
        galleryEmptyState = findViewById(R.id.galleryEmptyState)
        galleryCountBadge = findViewById(R.id.galleryCountBadge)
    }

    private fun loadInitialData() {
        currentColor = NoteStore.getDefaultColor(this)
        allSavedNotes = NoteStore.loadNotes(this)
    }

    // ==========================================
    // 1. لوحة التحكم السريعة (Power Action Bar)
    // ==========================================

    private fun setupPowerActionBar() {
        actionButton.setOnClickListener {
            handlePrimaryAction()
        }

        btnPowerLaunch.setOnClickListener {
            btnPowerLaunch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            launchFloatingNotes()
        }

        btnPowerAdd.setOnClickListener {
            btnPowerAdd.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            if (ensurePermissionsGranted()) {
                val newNote = NoteData(
                    id = UUID.randomUUID().toString(),
                    color = currentColor,
                    sizePreset = 0,
                    text = ""
                )
                allSavedNotes.add(newNote)
                NoteStore.saveNotes(this, allSavedNotes)
                refreshGallery()

                val intent = Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_ADD_NOTE
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "تم إطلاق نوتة عائمة جديدة 📝", Toast.LENGTH_SHORT).show()
            }
        }

        btnPowerGather.setOnClickListener {
            btnPowerGather.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_GATHER
            }
            startService(intent)
            Toast.makeText(this, "تم تجميع كل النوتات المتناثرة 🪄", Toast.LENGTH_SHORT).show()
        }

        btnPowerHide.setOnClickListener {
            btnPowerHide.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "تم إخفاء النوتات العائمة مؤقتاً", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handlePrimaryAction() {
        when {
            !Settings.canDrawOverlays(this) -> {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            !isIgnoringBatteryOptimizations() -> {
                requestIgnoreBatteryOptimizations()
            }
            else -> {
                launchFloatingNotes()
            }
        }
    }

    private fun ensurePermissionsGranted(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return false
        }
        return true
    }

    private fun launchFloatingNotes() {
        if (ensurePermissionsGranted()) {
            ContextCompat.startForegroundService(
                this, Intent(this, OverlayService::class.java)
            )
            Toast.makeText(this, "تم تشغيل النوتات العائمة بنجاح ✨", Toast.LENGTH_SHORT).show()
        }
    }

    // ==========================================
    // 2. محاكي الشاشة الحية (Live Interactive Phone Simulator)
    // ==========================================

    @SuppressLint("ClickableViewAccessibility")
    private fun setupLivePhoneSimulator() {
        updateSimulatorVisuals()

        var dX = 0f
        var dY = 0f
        var isDragging = false

        simNoteDraggable.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dX = view.x - event.rawX
                    dY = view.y - event.rawY
                    isDragging = false
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val parentW = simPhoneScreen.width.toFloat()
                    val parentH = simPhoneScreen.height.toFloat()
                    val viewW = view.width.toFloat()
                    val viewH = view.height.toFloat()

                    val targetX = (event.rawX + dX).coerceIn(4f, (parentW - viewW - 4f).coerceAtLeast(0f))
                    val targetY = (event.rawY + dY).coerceIn(4f, (parentH - viewH - 4f).coerceAtLeast(0f))

                    view.x = targetX
                    view.y = targetY
                    isDragging = true
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    true
                }
                else -> false
            }
        }

        simSizeBadge.setOnClickListener {
            simSizeBadge.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            studioSelectedSize = if (studioSelectedSize == 0) 1 else 0
            updateStudioSizeVisuals()
            updateSimulatorVisuals()
        }

        simMinBtn.setOnClickListener {
            simMinBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            val isGone = findViewById<View>(R.id.simContentBox).visibility == View.GONE
            findViewById<View>(R.id.simContentBox).visibility = if (isGone) View.VISIBLE else View.GONE
            (simMinBtn as TextView).text = if (isGone) "—" else "+"
        }

        simResetSimBtn.setOnClickListener {
            simResetSimBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            simNoteDraggable.animate()
                .x(dp(10f))
                .y(dp(20f))
                .rotation(0f)
                .setDuration(280)
                .setInterpolator(OvershootInterpolator())
                .start()
        }
    }

    private fun updateSimulatorVisuals() {
        val parsedColor = safeParseColor(currentColor)

        val isDark = isColorDark(parsedColor)
        val textColor = if (isDark) Color.parseColor("#FFFFFF") else Color.parseColor("#2D2013")
        val hintColor = if (isDark) Color.parseColor("#B3FFFFFF") else Color.parseColor("#8A7A5D")
        val headerColor = if (isDark) Color.parseColor("#E0E0E0") else Color.parseColor("#5A471C")

        simNoteText.setTextColor(textColor)
        simNoteText.setHintTextColor(hintColor)
        findViewById<TextView>(R.id.simMinBtn).setTextColor(headerColor)

        // خلفية الورقة المربعة المستديرة
        val paperBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(14f)
            setColor(parsedColor)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        simNoteDraggable.background = paperBg

        // المقاسات المربعة المصغرة
        val isSmall = studioSelectedSize == 0
        val targetW = dp(if (isSmall) 125f else 155f).toInt()
        val targetH = dp(if (isSmall) 100f else 130f).toInt() // content box height (total note becomes 125dp or 155dp)

        simNoteDraggable.layoutParams = simNoteDraggable.layoutParams.apply {
            width = targetW
        }
        findViewById<View>(R.id.simContentBox).layoutParams = findViewById<View>(R.id.simContentBox).layoutParams.apply {
            height = targetH
        }

        simSizeBadge.text = if (isSmall) "S" else "M"
    }

    // ==========================================
    // 3. استوديو النوتة الفورية (Quick Note Studio)
    // ==========================================

    private fun setupQuickStudio() {
        updateStudioSizeVisuals()

        studioSizeSmallBtn.setOnClickListener {
            studioSizeSmallBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            studioSelectedSize = 0
            updateStudioSizeVisuals()
            updateSimulatorVisuals()
        }

        studioSizeMediumBtn.setOnClickListener {
            studioSizeMediumBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            studioSelectedSize = 1
            updateStudioSizeVisuals()
            updateSimulatorVisuals()
        }

        studioLaunchFloatingBtn.setOnClickListener {
            studioLaunchFloatingBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            val noteContent = studioNoteInput.text.toString().trim()
            if (ensurePermissionsGranted()) {
                val newNote = NoteData(
                    id = UUID.randomUUID().toString(),
                    text = noteContent,
                    color = currentColor,
                    sizePreset = studioSelectedSize,
                    ruledLines = studioRuledLines
                )
                allSavedNotes.add(newNote)
                NoteStore.saveNotes(this, allSavedNotes)
                refreshGallery()

                studioNoteInput.setText("")
                val intent = Intent(this, OverlayService::class.java)
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "تم إطلاق النوتة عائمة على الشاشة! 🚀", Toast.LENGTH_SHORT).show()
            }
        }

        studioSaveGalleryBtn.setOnClickListener {
            studioSaveGalleryBtn.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            val noteContent = studioNoteInput.text.toString().trim()
            if (noteContent.isEmpty()) {
                Toast.makeText(this, "اكتب نصاً للنوتة أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val newNote = NoteData(
                id = UUID.randomUUID().toString(),
                text = noteContent,
                color = currentColor,
                sizePreset = studioSelectedSize,
                ruledLines = studioRuledLines
            )
            allSavedNotes.add(0, newNote)
            NoteStore.saveNotes(this, allSavedNotes)
            refreshGallery()
            studioNoteInput.setText("")
            Toast.makeText(this, "تم حفظ النوتة في المعرض 💾", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStudioSizeVisuals() {
        val isSmall = studioSelectedSize == 0
        studioSizeSmallBtn.setBackgroundResource(
            if (isSmall) R.drawable.preset_badge_selected else R.drawable.preset_badge_unselected
        )
        studioSizeSmallBtn.setTextColor(if (isSmall) Color.parseColor("#FFD54F") else Color.parseColor("#9E9E9E"))

        studioSizeMediumBtn.setBackgroundResource(
            if (!isSmall) R.drawable.preset_badge_selected else R.drawable.preset_badge_unselected
        )
        studioSizeMediumBtn.setTextColor(if (!isSmall) Color.parseColor("#FFD54F") else Color.parseColor("#9E9E9E"))
    }

    // ==========================================
    // 4. معرض النوتات المحفوظة (Notes Gallery)
    // ==========================================

    private fun setupNotesGallery() {
        refreshGallery()

        gallerySearchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterGallery(s.toString())
            }
        })
    }

    private fun refreshGallery(filterQuery: String = "") {
        galleryNotesContainer.removeAllViews()
        val list = if (filterQuery.isBlank()) {
            allSavedNotes
        } else {
            allSavedNotes.filter { it.text.contains(filterQuery, ignoreCase = true) }
        }

        galleryCountBadge.text = "${allSavedNotes.size} نوتة"

        if (list.isEmpty()) {
            galleryEmptyState.visibility = View.VISIBLE
            galleryNotesContainer.visibility = View.GONE
            return
        }

        galleryEmptyState.visibility = View.GONE
        galleryNotesContainer.visibility = View.VISIBLE

        val inflater = LayoutInflater.from(this)
        list.forEach { note ->
            val card = inflater.inflate(R.layout.item_gallery_note, galleryNotesContainer, false)

            val colorStrip = card.findViewById<View>(R.id.cardColorStrip)
            val notePreview = card.findViewById<TextView>(R.id.cardNoteText)
            val sizeBadge = card.findViewById<TextView>(R.id.cardSizeBadge)
            val btnLaunchSingle = card.findViewById<View>(R.id.cardBtnLaunch)
            val btnCopy = card.findViewById<View>(R.id.cardBtnCopy)
            val btnEdit = card.findViewById<View>(R.id.cardBtnEdit)
            val btnDelete = card.findViewById<View>(R.id.cardBtnDelete)

            val parsedColor = safeParseColor(note.color)
            val stripBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(parsedColor)
                cornerRadius = dp(4f)
            }
            colorStrip.background = stripBg

            notePreview.text = if (note.text.isBlank()) "(نوتة فارغة)" else note.text
            sizeBadge.text = if (note.sizePreset == 0) "صغير S" else "متوسط M"

            btnCopy.setOnClickListener {
                btnCopy.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Saved Note", note.text))
                Toast.makeText(this, "تم نسخ نص النوتة بنجاح ✓", Toast.LENGTH_SHORT).show()
            }

            btnLaunchSingle.setOnClickListener {
                btnLaunchSingle.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                if (ensurePermissionsGranted()) {
                    val intent = Intent(this, OverlayService::class.java)
                    ContextCompat.startForegroundService(this, intent)
                    Toast.makeText(this, "تم إطلاق النوتات عائمة ✨", Toast.LENGTH_SHORT).show()
                }
            }

            btnEdit.setOnClickListener {
                btnEdit.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                showEditNoteDialog(note)
            }

            btnDelete.setOnClickListener {
                btnDelete.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                allSavedNotes.remove(note)
                NoteStore.saveNotes(this, allSavedNotes)
                refreshGallery(gallerySearchInput.text.toString())
                Toast.makeText(this, "تم حذف النوتة", Toast.LENGTH_SHORT).show()
            }

            galleryNotesContainer.addView(card)
        }
    }

    private fun filterGallery(query: String) {
        refreshGallery(query)
    }

    private fun showEditNoteDialog(note: NoteData) {
        val editView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_note, null)
        val editInput = editView.findViewById<EditText>(R.id.dialogEditInput)
        editInput.setText(note.text)

        AlertDialog.Builder(this)
            .setTitle("تعديل النوتة")
            .setView(editView)
            .setPositiveButton("حفظ") { _, _ ->
                note.text = editInput.text.toString()
                NoteStore.saveNotes(this, allSavedNotes)
                refreshGallery(gallerySearchInput.text.toString())
                Toast.makeText(this, "تم حفظ التعديلات", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ==========================================
    // 5. محدد الألوان في الإعدادات
    // ==========================================

    private fun setupPaletteSelector() {
        paletteSwatchesContainer.removeAllViews()
        swatchViews.clear()

        val swatchSize = dp(38f).toInt()
        val margin = dp(5f).toInt()

        PALETTE.forEach { hex ->
            val swatch = View(this)
            val lp = LinearLayout.LayoutParams(swatchSize, swatchSize).apply {
                setMargins(margin, margin, margin, margin)
            }
            swatch.layoutParams = lp

            val parsedColor = safeParseColor(hex)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(parsedColor)
            }
            swatch.background = bg
            swatch.elevation = dp(2f)

            swatch.setOnClickListener {
                swatch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                selectColor(hex)
            }

            paletteSwatchesContainer.addView(swatch)
            swatchViews.add(hex to swatch)
        }
        refreshSwatchSelections()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHueBar() {
        val hueColors = IntArray(13) { i -> Color.HSVToColor(floatArrayOf(i * 30f, 0.45f, 0.97f)) }
        val hueDrawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hueColors).apply {
            cornerRadius = dp(8f)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        settingsHueBar.background = hueDrawable

        settingsHueBar.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    val fraction = (event.x / v.width).coerceIn(0f, 1f)
                    val hue = fraction * 360f
                    val pickedColor = Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.97f))
                    val hex = String.format("#%06X", 0xFFFFFF and pickedColor)
                    selectColor(hex)
                    true
                }
                else -> true
            }
        }
    }

    private fun selectColor(hex: String) {
        currentColor = hex
        NoteStore.setDefaultColor(this, hex)
        updateColorDisplay(hex)
        refreshSwatchSelections()
        updateSimulatorVisuals()
    }

    private fun updateColorDisplay(hex: String) {
        val parsed = safeParseColor(hex)
        val indicatorBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(parsed)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        selectedColorIndicator.background = indicatorBg
        selectedColorText.text = hex
    }

    private fun refreshSwatchSelections() {
        val normalizedCurrent = currentColor.uppercase()
        swatchViews.forEach { (hex, view) ->
            val isSelected = hex.uppercase() == normalizedCurrent
            val parsed = safeParseColor(hex)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(parsed)
                if (isSelected) {
                    setStroke(dp(3.5f).toInt(), Color.parseColor("#FFD54F"))
                } else {
                    setStroke(dp(1f).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = bg
            view.scaleX = if (isSelected) 1.15f else 1.0f
            view.scaleY = if (isSelected) 1.15f else 1.0f
        }
    }

    private fun safeParseColor(colorStr: String): Int {
        return try {
            Color.parseColor(colorStr)
        } catch (e: Exception) {
            Color.parseColor(NoteStore.DEFAULT_COLOR_VALUE)
        }
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.isIgnoringBatteryOptimizations(packageName)
    }

    private fun requestIgnoreBatteryOptimizations() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
            try {
                startActivity(fallbackIntent)
            } catch (e2: Exception) {
                // تجاهل
            }
        }
    }

    private fun checkForUpdate() {
        Thread {
            try {
                val url = URL(VERSION_CHECK_URL)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 4000
                connection.readTimeout = 4000
                val response = connection.inputStream.bufferedReader().readText()
                val json = JSONObject(response)
                val latestVersion = json.getString("latest")
                val downloadUrl = json.getString("url")
                if (latestVersion != CURRENT_VERSION) {
                    runOnUiThread {
                        updateBanner.visibility = View.VISIBLE
                        updateBanner.text = "نسخة جديدة ($latestVersion) متوفرة - انقر للتحديث"
                        updateBanner.setOnClickListener {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)))
                        }
                    }
                }
            } catch (e: Exception) {
                // تجاهل
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        allSavedNotes = NoteStore.loadNotes(this)
        refreshGallery(gallerySearchInput.text.toString())

        when {
            !Settings.canDrawOverlays(this) -> {
                statusBadge.text = "مطلوب إذن العرض فوق التطبيقات"
                statusBadge.setBackgroundResource(R.drawable.badge_warning_background)
                actionButton.text = "منح إذن العرض"
            }
            !isIgnoringBatteryOptimizations() -> {
                statusBadge.text = "مطلوب استثناء توفير البطارية"
                statusBadge.setBackgroundResource(R.drawable.badge_warning_background)
                actionButton.text = "استثناء البطارية"
            }
            else -> {
                statusBadge.text = "النظام جاهز والنوتات نشطة"
                statusBadge.setBackgroundResource(R.drawable.badge_ready_background)
                actionButton.text = "إطلاق النوتات العائمة"
            }
        }
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    private fun isColorDark(color: Int): Boolean {
        val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return darkness >= 0.5
    }

    companion object {
        private const val CURRENT_VERSION = "1.0"
        private const val VERSION_CHECK_URL = "https://YOUR-WEBSITE-DOMAIN/version.json"
        private val PALETTE = listOf(
            "#FFE066", "#800020", "#A8D8B9", "#F7A1A1", "#A8C8E8", "#D9B8F0",
            "#FFC48C", "#8FE0D0", "#F5A6C9", "#C9E4A8", "#E8D2A6"
        )
    }
}

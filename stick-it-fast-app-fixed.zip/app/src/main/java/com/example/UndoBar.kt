package com.example

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class UndoBar(
    private val context: Context,
    private val windowManager: WindowManager
) {
    private var view: View? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }
    }

    fun show(message: String, actionLabel: String, onAction: () -> Unit) {
        dismiss()

        val barView = LayoutInflater.from(context).inflate(R.layout.undo_bar, null)
        val messageText = barView.findViewById<TextView>(R.id.undoMessage)
        val actionText = barView.findViewById<TextView>(R.id.undoAction)
        messageText.text = message
        actionText.text = actionLabel

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(90f).toInt()
        }

        actionText.setOnClickListener {
            onAction()
        }

        barView.alpha = 0f
        barView.translationY = dp(30f)

        try {
            windowManager.addView(barView, params)
            view = barView
            barView.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(200)
                .start()
        } catch (e: Exception) {
            // لو مقدرش يضيف النافذة (الإذن اتشال فجأة مثلًا)، نتجاهل بهدوء
        }
    }

    fun dismiss() {
        val current = view ?: return
        view = null
        try {
            current.animate()
                .alpha(0f)
                .translationY(dp(20f))
                .setDuration(150)
                .withEndAction {
                    try {
                        windowManager.removeView(current)
                    } catch (e: Exception) {
                        // اتشالت أصلاً - نتجاهل بهدوء
                    }
                }
                .start()
        } catch (e: Exception) {
            try {
                windowManager.removeView(current)
            } catch (e2: Exception) {
                // تجاهل بهدوء
            }
        }
    }

    private fun dp(value: Float): Float = value * context.resources.displayMetrics.density
}

package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * خطوط تسطير الورقة الدقيقة (Ruled Paper Lines)
 * ترسم أسطر كتابة إرشادية خفيفة وأنيقة تحاكي أوراق الملاحظات المكتبية الفاخرة
 */
class RuledLinesView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = Color.parseColor("#28000000") // خط دقيق ناعم
    }

    private val lineSpacing = dp(24f)
    private val startOffsetY = dp(14f)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (visibility != VISIBLE) return

        val w = width.toFloat()
        val h = height.toFloat()
        val padX = dp(12f)

        var y = startOffsetY
        while (y < h - dp(10f)) {
            canvas.drawLine(padX, y, w - padX, y, linePaint)
            y += lineSpacing
        }
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}

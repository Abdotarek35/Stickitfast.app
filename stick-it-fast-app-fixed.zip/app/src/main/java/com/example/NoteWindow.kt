package com.example

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.abs

class NoteWindow(
    private val context: Context,
    private val windowManager: WindowManager,
    val data: NoteData,
    private val onRemove: (NoteWindow) -> Unit,
    private val onChanged: () -> Unit
) {
    private val view: View = LayoutInflater.from(context).inflate(R.layout.note_overlay, null)

    // مهم جدًا: FLAG_NOT_FOCUSABLE افتراضيًا عشان النافذة العائمة متاخدش تركيز الكيبورد
    // أو تعطّل إيماءات النظام (زي السحب من الحواف) طول ما هي موجودة على الشاشة.
    // بنشيلها مؤقتًا بس وقت الكتابة الفعلية جوه النوتة (enterEditMode/exitEditMode تحت).
    // FLAG_WATCH_OUTSIDE_TOUCH: نوافذ TYPE_APPLICATION_OVERLAY مش بتفقد "تركيز النافذة"
    // بشكل موثوق لما تدوس في تطبيق تاني (عكس نافذة نشاط عادية) - فالاعتماد على فقدان
    // التركيز بس مش كافي. الفلاج ده بيدّينا حدث ACTION_OUTSIDE صريح لما تدوس برا حدود
    // النافذة، وده نفس الأسلوب اللي بتستخدمه PopupWindow نفسها داخليًا (isOutsideTouchable).
    private val params: WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = data.x
        y = data.y
    }

    private var isEditingText = false

    private val fullNoteGroup: View = view.findViewById(R.id.fullNoteGroup)
    private val fullNote: View = view.findViewById(R.id.fullNote)
    private val topBar: LinearLayout = view.findViewById(R.id.topBar)
    private val contentContainer: FrameLayout = view.findViewById(R.id.contentContainer)

    private val minimizedDot: FrameLayout = view.findViewById(R.id.minimizedDot)
    private val minimizedBubbleBody: View = view.findViewById(R.id.minimizedBubbleBody)

    private val noteText: EditText = view.findViewById(R.id.noteText)
    private val ruledLinesView: RuledLinesView = view.findViewById(R.id.ruledLinesView)
    private val paperCurlView: PaperCurlView = view.findViewById(R.id.paperCurlView)
    private val dragHandle: View = view.findViewById(R.id.dragHandle)
    private val pinButton: ImageView = view.findViewById(R.id.pinButton)
    private val colorButton: View = view.findViewById(R.id.colorButton)
    private val closeButton: View = view.findViewById(R.id.closeButton)

    private var colorPopup: PopupWindow? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }
    }

    init {
        fullNote.clipToOutline = true
        view.clipToOutline = false
        windowManager.addView(view, params)
        noteText.setText(data.text)

        applySizePreset(animate = false)
        applyColor()
        applyLockedVisual()
        ruledLinesView.visibility = if (data.ruledLines) View.VISIBLE else View.GONE
        refreshMinimizedState(animate = false)
        playEntranceAnimation()

        noteText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                data.text = s.toString()
                onChanged()
            }
        })

        closeButton.setOnClickListener {
            closeButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            animateClose { onRemove(this) }
        }

        pinButton.setOnClickListener {
            data.locked = !data.locked
            pinButton.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            applyLockedVisual()
            onChanged()
        }

        colorButton.setOnClickListener {
            showColorPicker()
        }

        setupTextEditingFocus()
        setupTouch()
    }

    // ---------- حل مشكلة الكيبورد وتعطّل إيماءات النظام ----------
    // النافذة العائمة FLAG_NOT_FOCUSABLE افتراضيًا (مش بتاخد تركيز الكيبورد أو تعطّل حاجة).
    // لما تدوس فعليًا جوه مكان الكتابة، بنفعّل التركيز مؤقتًا بس، وبمجرد ما تدوس في أي
    // حتة تانية برا النوتة (حتى لو في تطبيق تاني) هيتقفل الكيبورد ويرجع الوضع الطبيعي لوحده.
    //
    // ملحوظة مهمة: كان فيه هنا قبل كده رصد لظهور/اختفاء الكيبورد عن طريق
    // ViewTreeObserver.OnGlobalLayoutListener - اتشال نهائيًا بعد ما اتأكد إنه بيسبب
    // كراش NullPointerException متكرر جوه أندرويد نفسه (ViewTreeObserver.dispatchOnGlobalLayout)
    // حتى مع تسجيل واحد بس للـ listener. الاعتماد بقى فقط على ACTION_OUTSIDE، وهي
    // نفس الآلية اللي بتستخدمها PopupWindow في أندرويد نفسه من سنين - أضمن وأبسط.

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTextEditingFocus() {
        noteText.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN && !data.locked) {
                enterEditMode()
            }
            false
        }

        // خط الدفاع الأساسي: لمسة صريحة برا حدود النافذة (بفضل FLAG_WATCH_OUTSIDE_TOUCH)
        view.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_OUTSIDE && isEditingText) {
                exitEditMode()
            }
            false
        }

        // خط دفاع إضافي بسيط وآمن: لو زرار الرجوع وصل فعليًا لحقل الكتابة (بعض
        // الأجهزة بتسيبه يوصل بعد إغلاق الكيبورد)، نتأكد إننا نخرج من وضع الكتابة
        noteText.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK &&
                event.action == android.view.KeyEvent.ACTION_UP && isEditingText
            ) {
                exitEditMode()
            }
            false
        }
    }

    private fun enterEditMode() {
        if (isEditingText) return
        isEditingText = true
        params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        safeUpdateLayout()
        noteText.post {
            noteText.requestFocus()
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(noteText, InputMethodManager.SHOW_FORCED)
        }
    }

    private fun exitEditMode() {
        if (!isEditingText) return
        isEditingText = false
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(noteText.windowToken, 0)
        noteText.clearFocus()
        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_UNCHANGED
        safeUpdateLayout()
    }

    // ---------- المقاسات المربعة المستديرة (مقاس واحد يتحدد وقت إنشاء النوتة بس) ----------

    // بيتراعى فيه حجم الشاشة: 3 مستويات واضحة، كل مستوى أصغر من اللي بعده بمقدار
    // 20dp صافي في العرض والارتفاع مع بعض - مش نسبة مئوية غامضة زي الأول
    private fun deviceSizeTier(): Int {
        val smallestWidthDp = context.resources.configuration.smallestScreenWidthDp
        return when {
            smallestWidthDp >= 840 -> 2 // شاشة كبيرة (كمبيوتر/كروم بوك) - أكبر مقاس
            smallestWidthDp >= 600 -> 1 // تابلت - متوسط
            else -> 0                    // موبايل - أصغر مقاس
        }
    }

    private fun applySizePreset(animate: Boolean) {
        val isSmall = data.sizePreset == 0
        val tier = deviceSizeTier()

        // كل مستوى جهاز له مقاس صريح مكتوب بالرقم - سهل تتأكد بيه بالعين المجردة:
        // موبايل: 120/140 | تابلت: 140/160 | كمبيوتر: 160/180 (فرق 20dp صافي بين كل مستوى)
        val targetWidthDp = when (tier) {
            2 -> if (isSmall) 160f else 180f
            1 -> if (isSmall) 140f else 160f
            else -> if (isSmall) 120f else 140f
        }
        val targetHeightDp = targetWidthDp - 26f // شريط العنوان ثابت 26dp في كل المقاسات

        val targetWidthPx = dp(targetWidthDp).toInt()
        val targetHeightPx = dp(targetHeightDp).toInt()

        updateDimensions(targetWidthPx, targetHeightPx)

        if (animate) {
            fullNoteGroup.scaleX = 0.92f
            fullNoteGroup.scaleY = 0.92f
            fullNoteGroup.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(220)
                .setInterpolator(OvershootInterpolator(1.4f))
                .start()
        }
    }

    private fun updateDimensions(widthPx: Int, heightPx: Int) {
        topBar.layoutParams = topBar.layoutParams.apply { width = widthPx }
        contentContainer.layoutParams = contentContainer.layoutParams.apply {
            width = widthPx
            height = heightPx
        }

        fullNoteGroup.requestLayout()
        safeUpdateLayout()
    }

    // ---------- الظهور والاختفاء ----------

    private fun playEntranceAnimation() {
        view.scaleX = 0f
        view.scaleY = 0f
        view.alpha = 0f
        view.animate()
            .scaleX(1f).scaleY(1f).alpha(data.opacity)
            .setDuration(220)
            .setInterpolator(OvershootInterpolator(1.6f))
            .start()
    }

    private fun animateClose(onFinished: () -> Unit) {
        view.animate()
            .scaleX(0.5f).scaleY(0.5f).alpha(0f)
            .setDuration(180)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { onFinished() }
            .start()
    }

    // ---------- الألوان المسطحة تماماً بدون ظلال أو ضوء أو تدرج ----------

    private fun applyColor() {
        val baseColor = safeParseColor(data.color)
        val isDark = isColorDark(baseColor)

        val textColor = if (isDark) Color.parseColor("#FFFFFF") else Color.parseColor("#2D2013")
        val hintColor = if (isDark) Color.parseColor("#B3FFFFFF") else Color.parseColor("#8A7A5D")
        val iconColor = if (isDark) Color.parseColor("#E0E0E0") else Color.parseColor("#5A4A2A")

        noteText.setTextColor(textColor)
        noteText.setHintTextColor(hintColor)
        (closeButton as? TextView)?.setTextColor(iconColor)
        pinButton.setColorFilter(iconColor)

        // جسم النوتة بلون مسطح خالص وحواف مستديرة
        fullNote.background = buildPaperDrawable(baseColor)

        // زاوية الورقة المطوية بنفس لون النوتة
        paperCurlView.setPaperColor(baseColor)

        // خلفية الفقاعة المصغرة
        val bubbleBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(baseColor)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        minimizedBubbleBody.background = bubbleBg

        // لون زر الباليت
        val paletteBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(baseColor)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        colorButton.background = paletteBtnBg
    }

    private fun safeParseColor(hex: String): Int {
        return try {
            Color.parseColor(hex)
        } catch (e: IllegalArgumentException) {
            Color.parseColor("#FFE066")
        }
    }

    private fun buildPaperDrawable(baseColor: Int): GradientDrawable {
        val gd = GradientDrawable()
        gd.shape = GradientDrawable.RECTANGLE
        gd.setColor(baseColor) // لون مسطح نقي
        gd.cornerRadius = dp(14f) // حواف مستديرة ناعمة
        return gd
    }

    private fun dp(value: Float): Float = value * context.resources.displayMetrics.density

    // ---------- لوحة اختيار الألوان ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun showColorPicker() {
        val pickerView = LayoutInflater.from(context).inflate(R.layout.note_color_picker, null)
        val paletteGrid = pickerView.findViewById<GridLayout>(R.id.paletteGrid)
        val hueBar = pickerView.findViewById<View>(R.id.hueBar)

        val popup = PopupWindow(
            pickerView,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            true
        )
        popup.isFocusable = true
        popup.isOutsideTouchable = true
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        colorPopup = popup

        PALETTE.forEach { hex ->
            val swatch = View(context)
            val size = dp(34f).toInt()
            val margin = dp(4f).toInt()
            val lp = GridLayout.LayoutParams().apply {
                width = size
                height = size
                setMargins(margin, margin, margin, margin)
            }
            swatch.layoutParams = lp

            val swatchBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(safeParseColor(hex))
                setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
            }
            swatch.background = swatchBg

            swatch.setOnClickListener {
                swatch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                data.color = hex
                applyColor()
                onChanged()
                popup.dismiss()
            }
            paletteGrid.addView(swatch)
        }

        val hueColors = IntArray(13) { i -> Color.HSVToColor(floatArrayOf(i * 30f, 0.45f, 0.97f)) }
        val hueDrawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hueColors).apply {
            cornerRadius = dp(6f)
        }
        hueBar.background = hueDrawable

        hueBar.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    val fraction = (event.x / v.width).coerceIn(0f, 1f)
                    val hue = fraction * 360f
                    val pickedColor = Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.97f))
                    data.color = String.format("#%06X", 0xFFFFFF and pickedColor)
                    applyColor()
                    onChanged()
                    true
                }
                else -> true
            }
        }

        popup.showAsDropDown(colorButton, 0, dp(8f).toInt())
    }

    // ---------- التصغير/الاسترجاع ----------

    private fun applyOpacity() {
        view.alpha = data.opacity
    }

    private fun applyLockedVisual() {
        pinButton.alpha = if (data.locked) 1f else 0.4f
    }

    private fun refreshMinimizedState(animate: Boolean = true) {
        val showing = if (data.minimized) minimizedDot else fullNoteGroup
        val hiding = if (data.minimized) fullNoteGroup else minimizedDot

        if (!animate) {
            fullNoteGroup.visibility = if (data.minimized) View.GONE else View.VISIBLE
            minimizedDot.visibility = if (data.minimized) View.VISIBLE else View.GONE
            safeUpdateLayout()
            return
        }

        hiding.animate().cancel()
        showing.animate().cancel()

        hiding.animate()
            .scaleX(0.4f).scaleY(0.4f).alpha(0f)
            .setDuration(120)
            .withEndAction {
                hiding.visibility = View.GONE
                hiding.scaleX = 1f
                hiding.scaleY = 1f
                hiding.alpha = 1f

                showing.visibility = View.VISIBLE
                showing.scaleX = 0.4f
                showing.scaleY = 0.4f
                showing.alpha = 0f
                safeUpdateLayout()

                showing.animate()
                    .scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(160)
                    .setInterpolator(OvershootInterpolator(1.4f))
                    .start()
            }
            .start()
    }

    // ---------- السحب واللمس مع الميلان الديناميكي والفيزياء (Dynamic Drag & Tilt) ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouch() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false
        var downTime = 0L

        val touchListener = View.OnTouchListener { touchedView, event ->
            if (data.locked) return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    downTime = System.currentTimeMillis()
                    touchedView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (abs(dx) > 6 || abs(dy) > 6) moved = true
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()

                    safeUpdateLayout()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    data.x = params.x
                    data.y = params.y
                    val isLongPress = System.currentTimeMillis() - downTime > 500

                    if (!moved) {
                        if (isLongPress) {
                            cycleOpacity()
                        } else {
                            data.minimized = !data.minimized
                            refreshMinimizedState()
                        }
                    } else if (touchedView == minimizedDot) {
                        // الاستقرار واللزوق على الحافة يشتغلوا بس لما النوتة مقفولة/مصغّرة
                        // على شكل دائرة - مش وهي مفتوحة بحجمها الكامل
                        playSettleBounce()
                        snapToNearestEdge()
                    }
                    onChanged()
                    true
                }
                else -> false
            }
        }

        dragHandle.setOnTouchListener(touchListener)
        minimizedDot.setOnTouchListener(touchListener)
    }

    // استقرار بسيط بعد ما تسيب النوتة من إيدك - إحساس فيزيائي خفيف
    private fun playSettleBounce() {
        view.animate().cancel()
        view.animate()
            .scaleX(1.06f).scaleY(1.06f)
            .setDuration(80)
            .withEndAction {
                view.animate()
                    .scaleX(1f).scaleY(1f)
                    .setDuration(140)
                    .setInterpolator(OvershootInterpolator(2f))
                    .start()
            }
            .start()
    }

    // بترمي النوتة تلزق في أقرب حافة (يمين أو شمال) بعد ما تسيبها - زي الـ chat heads
    private fun snapToNearestEdge() {
        val screenWidth = context.resources.displayMetrics.widthPixels
        val viewWidth = view.width.takeIf { it > 0 } ?: dp(40f).toInt()
        val maxX = (screenWidth - viewWidth).coerceAtLeast(0)
        val targetX = if (params.x + viewWidth / 2 < screenWidth / 2) 0 else maxX

        val animator = ValueAnimator.ofInt(params.x, targetX)
        animator.duration = 220
        animator.interpolator = OvershootInterpolator(0.9f)
        animator.addUpdateListener {
            params.x = it.animatedValue as Int
            safeUpdateLayout()
        }
        animator.start()
        data.x = targetX
    }

    private fun cycleOpacity() {
        data.opacity = when {
            data.opacity >= 0.99f -> 0.6f
            data.opacity >= 0.59f -> 0.3f
            else -> 1.0f
        }
        applyOpacity()
    }

    private fun safeUpdateLayout() {
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            // تجاهل في حالة الإزالة
        }
    }

    // ---------- تجميع النوتات ----------

    fun gatherTo(x: Int, y: Int, staggerMs: Long) {
        view.postDelayed({
            val animX = ValueAnimator.ofInt(params.x, x)
            val animY = ValueAnimator.ofInt(params.y, y)
            animX.addUpdateListener { params.x = it.animatedValue as Int; safeUpdateLayout() }
            animY.addUpdateListener { params.y = it.animatedValue as Int; safeUpdateLayout() }
            animX.duration = 260
            animY.duration = 260
            animX.interpolator = DecelerateInterpolator()
            animY.interpolator = DecelerateInterpolator()
            animX.start()
            animY.start()
            data.x = x
            data.y = y
        }, staggerMs)
    }

    fun detach() {
        colorPopup?.dismiss()
        try {
            windowManager.removeView(view)
        } catch (e: IllegalArgumentException) {
            // تم إزالتها مسبقاً
        }
    }

    private fun isColorDark(color: Int): Boolean {
        val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return darkness >= 0.5
    }

    companion object {
        private val PALETTE = listOf(
            "#FFE066", "#800020", "#A8D8B9", "#F7A1A1", "#A8C8E8", "#D9B8F0",
            "#FFC48C", "#8FE0D0", "#F5A6C9", "#C9E4A8", "#E8D2A6"
        )
    }
}

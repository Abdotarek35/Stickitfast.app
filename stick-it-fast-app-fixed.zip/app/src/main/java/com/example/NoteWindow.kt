package com.example

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.abs

class NoteWindow(
    private val context: Context,
    private val windowManager: WindowManager,
    val data: NoteData,
    private val onRemove: (NoteWindow) -> Unit,
    private val onAdd: () -> Unit,
    private val onChanged: () -> Unit
) {
    private val view: View = LayoutInflater.from(context).inflate(R.layout.note_overlay, null)
    private val params: WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = data.x
        y = data.y
    }

    private val fullNoteGroup: View = view.findViewById(R.id.fullNoteGroup)
    private val fullNote: View = view.findViewById(R.id.fullNote)
    private val topBar: LinearLayout = view.findViewById(R.id.topBar)
    private val contentContainer: FrameLayout = view.findViewById(R.id.contentContainer)

    private val minimizedDot: FrameLayout = view.findViewById(R.id.minimizedDot)
    private val minimizedBubbleBody: View = view.findViewById(R.id.minimizedBubbleBody)

    private val noteText: EditText = view.findViewById(R.id.noteText)
    private val dragHandle: View = view.findViewById(R.id.dragHandle)
    private val pinButton: ImageView = view.findViewById(R.id.pinButton)
    private val colorButton: View = view.findViewById(R.id.colorButton)
    private val addButton: View = view.findViewById(R.id.addButton)
    private val closeButton: View = view.findViewById(R.id.closeButton)

    private val sizePresetButton: TextView = view.findViewById(R.id.sizePresetButton)

    private var colorPopup: PopupWindow? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }
    }

    init {
        fullNote.clipToOutline = true
        view.clipToOutline = false
        windowManager.addView(view, params)
        noteText.setText(data.text)

        applySizePreset(animate = false)
        applyColor()
        applyLockedVisual()
        refreshMinimizedState(animate = false)
        playEntranceAnimation()

        noteText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                data.text = s.toString()
                onChanged()
            }
        })

        closeButton.setOnClickListener {
            closeButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            animateClose { onRemove(this) }
        }

        addButton.setOnClickListener { onAdd() }

        pinButton.setOnClickListener {
            data.locked = !data.locked
            pinButton.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            applyLockedVisual()
            onChanged()
        }

        colorButton.setOnClickListener {
            showColorPicker()
        }

        sizePresetButton.setOnClickListener {
            sizePresetButton.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            cycleSizePreset()
        }

        setupTouch()
    }

    // ---------- المقاسات المربعة المستديرة (160x160 و 180x180) ----------

    private fun cycleSizePreset() {
        // صغير مربع (0 = 160x160dp) <-> متوسط مربع (1 = 180x180dp)
        data.sizePreset = if (data.sizePreset == 0) 1 else 0
        applySizePreset(animate = true)
        onChanged()
    }

    private fun applySizePreset(animate: Boolean) {
        val isSmall = data.sizePreset == 0
        // المقاس الصغير: 160x160 dp | المقاس المتوسط: 180x180 dp
        val targetWidthDp = if (isSmall) 160f else 180f
        val targetHeightDp = if (isSmall) 134f else 154f // 134 + 26 = 160dp, 154 + 26 = 180dp

        sizePresetButton.text = if (isSmall) "S" else "M"
        sizePresetButton.alpha = if (isSmall) 0.85f else 1.0f

        val targetWidthPx = dp(targetWidthDp).toInt()
        val targetHeightPx = dp(targetHeightDp).toInt()

        updateDimensions(targetWidthPx, targetHeightPx)

        if (animate) {
            fullNoteGroup.scaleX = 0.92f
            fullNoteGroup.scaleY = 0.92f
            fullNoteGroup.animate()
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(220)
                .setInterpolator(OvershootInterpolator(1.4f))
                .start()
        }
    }

    private fun updateDimensions(widthPx: Int, heightPx: Int) {
        topBar.layoutParams = topBar.layoutParams.apply { width = widthPx }
        contentContainer.layoutParams = contentContainer.layoutParams.apply {
            width = widthPx
            height = heightPx
        }

        fullNoteGroup.requestLayout()
        safeUpdateLayout()
    }

    // ---------- الظهور والاختفاء ----------

    private fun playEntranceAnimation() {
        view.scaleX = 0f
        view.scaleY = 0f
        view.alpha = 0f
        view.animate()
            .scaleX(1f).scaleY(1f).alpha(data.opacity)
            .setDuration(220)
            .setInterpolator(OvershootInterpolator(1.6f))
            .start()
    }

    private fun animateClose(onFinished: () -> Unit) {
        view.animate()
            .scaleX(0.5f).scaleY(0.5f).alpha(0f)
            .setDuration(180)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { onFinished() }
            .start()
    }

    // ---------- الألوان المسطحة تماماً بدون ظلال أو ضوء أو تدرج ----------

    private fun applyColor() {
        val baseColor = safeParseColor(data.color)
        val isDark = isColorDark(baseColor)

        val textColor = if (isDark) Color.parseColor("#FFFFFF") else Color.parseColor("#2D2013")
        val hintColor = if (isDark) Color.parseColor("#B3FFFFFF") else Color.parseColor("#8A7A5D")
        val iconColor = if (isDark) Color.parseColor("#E0E0E0") else Color.parseColor("#5A4A2A")

        noteText.setTextColor(textColor)
        noteText.setHintTextColor(hintColor)
        sizePresetButton.setTextColor(iconColor)
        (addButton as? TextView)?.setTextColor(iconColor)
        (closeButton as? TextView)?.setTextColor(iconColor)
        pinButton.setColorFilter(iconColor)

        // جسم النوتة بلون مسطح خالص وحواف مستديرة
        fullNote.background = buildPaperDrawable(baseColor)

        // خلفية الفقاعة المصغرة
        val bubbleBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(baseColor)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        minimizedBubbleBody.background = bubbleBg

        // لون زر الباليت
        val paletteBtnBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(baseColor)
            setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
        }
        colorButton.background = paletteBtnBg
    }

    private fun safeParseColor(hex: String): Int {
        return try {
            Color.parseColor(hex)
        } catch (e: IllegalArgumentException) {
            Color.parseColor("#FFE066")
        }
    }

    private fun buildPaperDrawable(baseColor: Int): GradientDrawable {
        val gd = GradientDrawable()
        gd.shape = GradientDrawable.RECTANGLE
        gd.setColor(baseColor) // لون مسطح نقي
        gd.cornerRadius = dp(14f) // حواف مستديرة ناعمة
        return gd
    }

    private fun dp(value: Float): Float = value * context.resources.displayMetrics.density

    // ---------- لوحة اختيار الألوان ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun showColorPicker() {
        val pickerView = LayoutInflater.from(context).inflate(R.layout.note_color_picker, null)
        val paletteGrid = pickerView.findViewById<GridLayout>(R.id.paletteGrid)
        val hueBar = pickerView.findViewById<View>(R.id.hueBar)

        val popup = PopupWindow(
            pickerView,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            true
        )
        popup.isFocusable = true
        popup.isOutsideTouchable = true
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        colorPopup = popup

        PALETTE.forEach { hex ->
            val swatch = View(context)
            val size = dp(34f).toInt()
            val margin = dp(4f).toInt()
            val lp = GridLayout.LayoutParams().apply {
                width = size
                height = size
                setMargins(margin, margin, margin, margin)
            }
            swatch.layoutParams = lp

            val swatchBg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(safeParseColor(hex))
                setStroke(dp(1f).toInt(), Color.parseColor("#33000000"))
            }
            swatch.background = swatchBg

            swatch.setOnClickListener {
                swatch.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                data.color = hex
                applyColor()
                onChanged()
                popup.dismiss()
            }
            paletteGrid.addView(swatch)
        }

        val hueColors = IntArray(13) { i -> Color.HSVToColor(floatArrayOf(i * 30f, 0.45f, 0.97f)) }
        val hueDrawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, hueColors).apply {
            cornerRadius = dp(6f)
        }
        hueBar.background = hueDrawable

        hueBar.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    val fraction = (event.x / v.width).coerceIn(0f, 1f)
                    val hue = fraction * 360f
                    val pickedColor = Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.97f))
                    data.color = String.format("#%06X", 0xFFFFFF and pickedColor)
                    applyColor()
                    onChanged()
                    true
                }
                else -> true
            }
        }

        popup.showAsDropDown(colorButton, 0, dp(8f).toInt())
    }

    // ---------- التصغير/الاسترجاع ----------

    private fun applyOpacity() {
        view.alpha = data.opacity
    }

    private fun applyLockedVisual() {
        pinButton.alpha = if (data.locked) 1f else 0.4f
    }

    private fun refreshMinimizedState(animate: Boolean = true) {
        val showing = if (data.minimized) minimizedDot else fullNoteGroup
        val hiding = if (data.minimized) fullNoteGroup else minimizedDot

        if (!animate) {
            fullNoteGroup.visibility = if (data.minimized) View.GONE else View.VISIBLE
            minimizedDot.visibility = if (data.minimized) View.VISIBLE else View.GONE
            safeUpdateLayout()
            return
        }

        hiding.animate().cancel()
        showing.animate().cancel()

        hiding.animate()
            .scaleX(0.4f).scaleY(0.4f).alpha(0f)
            .setDuration(120)
            .withEndAction {
                hiding.visibility = View.GONE
                hiding.scaleX = 1f
                hiding.scaleY = 1f
                hiding.alpha = 1f

                showing.visibility = View.VISIBLE
                showing.scaleX = 0.4f
                showing.scaleY = 0.4f
                showing.alpha = 0f
                safeUpdateLayout()

                showing.animate()
                    .scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(160)
                    .setInterpolator(OvershootInterpolator(1.4f))
                    .start()
            }
            .start()
    }

    // ---------- السحب واللمس مع الميلان الديناميكي والفيزياء (Dynamic Drag & Tilt) ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouch() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var moved = false
        var downTime = 0L

        val touchListener = View.OnTouchListener { touchedView, event ->
            if (data.locked) return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    moved = false
                    downTime = System.currentTimeMillis()
                    touchedView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (abs(dx) > 6 || abs(dy) > 6) moved = true
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()

                    safeUpdateLayout()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    data.x = params.x
                    data.y = params.y
                    val isLongPress = System.currentTimeMillis() - downTime > 500

                    if (!moved) {
                        if (isLongPress) {
                            cycleOpacity()
                        } else {
                            data.minimized = !data.minimized
                            refreshMinimizedState()
                        }
                    }
                    onChanged()
                    true
                }
                else -> false
            }
        }

        dragHandle.setOnTouchListener(touchListener)
        minimizedDot.setOnTouchListener(touchListener)
    }

    private fun cycleOpacity() {
        data.opacity = when {
            data.opacity >= 0.99f -> 0.6f
            data.opacity >= 0.59f -> 0.3f
            else -> 1.0f
        }
        applyOpacity()
    }

    private fun safeUpdateLayout() {
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            // تجاهل في حالة الإزالة
        }
    }

    // ---------- تجميع النوتات ----------

    fun gatherTo(x: Int, y: Int, staggerMs: Long) {
        view.postDelayed({
            val animX = ValueAnimator.ofInt(params.x, x)
            val animY = ValueAnimator.ofInt(params.y, y)
            animX.addUpdateListener { params.x = it.animatedValue as Int; safeUpdateLayout() }
            animY.addUpdateListener { params.y = it.animatedValue as Int; safeUpdateLayout() }
            animX.duration = 260
            animY.duration = 260
            animX.interpolator = DecelerateInterpolator()
            animY.interpolator = DecelerateInterpolator()
            animX.start()
            animY.start()
            data.x = x
            data.y = y
        }, staggerMs)
    }

    fun detach() {
        colorPopup?.dismiss()
        try {
            windowManager.removeView(view)
        } catch (e: IllegalArgumentException) {
            // تم إزالتها مسبقاً
        }
    }

    private fun isColorDark(color: Int): Boolean {
        val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
        return darkness >= 0.5
    }

    companion object {
        private val PALETTE = listOf(
            "#FFE066", "#800020", "#A8D8B9", "#F7A1A1", "#A8C8E8", "#D9B8F0",
            "#FFC48C", "#8FE0D0", "#F5A6C9", "#C9E4A8", "#E8D2A6"
        )
    }
}

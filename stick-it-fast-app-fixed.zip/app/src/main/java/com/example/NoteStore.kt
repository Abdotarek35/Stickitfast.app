package com.example

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class NoteData(
    var id: String,
    var text: String = "",
    var x: Int = 100,
    var y: Int = 200,
    var color: String = "#FFE066",
    var locked: Boolean = false,
    var minimized: Boolean = false,
    var opacity: Float = 1.0f,
    var sizePreset: Int = 0, // 0 = صغير (215dp - الافتراضي والأساسي), 1 = متوسط (255dp)
    var ruledLines: Boolean = true // خطوط التسطير مفعلة افتراضياً
)

object NoteStore {
    private const val PREFS = "stick_it_fast_prefs"
    private const val KEY_NOTES = "notes_json"
    private const val KEY_DEFAULT_COLOR = "default_note_color"
    const val DEFAULT_COLOR_VALUE = "#FFE066"

    fun getDefaultColor(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_DEFAULT_COLOR, DEFAULT_COLOR_VALUE) ?: DEFAULT_COLOR_VALUE
    }

    fun setDefaultColor(context: Context, color: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_DEFAULT_COLOR, color)
            .apply()
    }

    fun loadNotes(context: Context): MutableList<NoteData> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_NOTES, null) ?: return mutableListOf()
        val list = mutableListOf<NoteData>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    NoteData(
                        id = o.getString("id"),
                        text = o.optString("text", ""),
                        x = o.optInt("x", 100),
                        y = o.optInt("y", 200),
                        color = o.optString("color", "#FFE066"),
                        locked = o.optBoolean("locked", false),
                        minimized = o.optBoolean("minimized", false),
                        opacity = o.optDouble("opacity", 1.0).toFloat(),
                        sizePreset = o.optInt("sizePreset", 0), // الافتراضي صغير
                        ruledLines = o.optBoolean("ruledLines", true)
                    )
                )
            }
        } catch (e: Exception) {
            return mutableListOf()
        }
        return list
    }

    fun saveNotes(context: Context, notes: List<NoteData>) {
        val arr = JSONArray()
        for (n in notes) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("text", n.text)
            o.put("x", n.x)
            o.put("y", n.y)
            o.put("color", n.color)
            o.put("locked", n.locked)
            o.put("minimized", n.minimized)
            o.put("opacity", n.opacity.toDouble())
            o.put("sizePreset", n.sizePreset)
            o.put("ruledLines", n.ruledLines)
            arr.put(o)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_NOTES, arr.toString())
            .apply()
    }
}

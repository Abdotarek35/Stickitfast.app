package com.example

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager

// زرار دائري ثابت أسفل يمين الشاشة لإضافة نوتة جديدة بسرعة - منفصل تمامًا عن أي نوتة.
class AddFab(
    private val context: Context,
    private val windowManager: WindowManager,
    private val onClick: () -> Unit
) {
    private var view: View? = null

    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
        }
    }

    fun show() {
        if (view != null) return

        val fabView = LayoutInflater.from(context).inflate(R.layout.fab_add_button, null)

        // FLAG_NOT_FOCUSABLE دايمًا هنا - زرار بسيط، مفيش كتابة، فمفيش داعي يتفاعل مع الكيبورد أصلًا
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = dp(20f).toInt()
            y = dp(90f).toInt()
        }

        fabView.setOnClickListener {
            fabView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onClick()
        }

        try {
            windowManager.addView(fabView, params)
            view = fabView
        } catch (e: Exception) {
            // تجاهل بهدوء لو الإذن اتشال فجأة أو أي مشكلة تانية
        }
    }

    fun hide() {
        val current = view ?: return
        view = null
        try {
            windowManager.removeView(current)
        } catch (e: Exception) {
            // اتشالت أصلاً - تجاهل بهدوء
        }
    }

    private fun dp(value: Float): Float = value * context.resources.displayMetrics.density
}
